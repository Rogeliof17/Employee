/**
 * Created by Genesis on 5/1/2016.
 */
public class Worker
{
    public static void main(String[] args)
    {
        createWorker("John Smith", "123-A", "11-15-2015",
                    ProductionWorker.DAY_SHIFT,26.50);

        System.out.println("\nAttempting an invalid Employee number ");
        createWorker("John Smith", "A-321", "11-15-2015",
                ProductionWorker.DAY_SHIFT,26.50);

        System.out.println("\nAttempting an invalid shift number");
        createWorker("John Smith", "123-A", "11-15-2015",
                        55,26.50);

        System.out.println("\nAttempting an invalid pay rate");
        createWorker("John Smith", "123-A", "11-15-2015",
                ProductionWorker.DAY_SHIFT,-99.00);
    }

    public static void createWorker(String n, String num, String date,
                                    int sh, double rate)
    {
        ProductionWorker pv;

        try
        {
            pv = new ProductionWorker(n, num, date, sh, rate);

            System.out.println("Object created");
            System.out.println(pv);
        }
        catch (InvalidEmployeeNumber e)
        {
            System.out.println(e.getMessage());
        }
        catch (InvalidShift e)
        {
            System.out.println(e.getMessage());
        }
        catch (InvalidPayRate e)
        {
            System.out.println(e.getMessage());
        }
    }
}
