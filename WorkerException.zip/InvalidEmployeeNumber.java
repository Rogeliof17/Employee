/**
 * Created by Genesis on 5/14/2016.
 */
public class InvalidEmployeeNumber extends Exception
{
    public InvalidEmployeeNumber()
    {
        super("ERROR: INVALID EMPLOYEE NUMBER");
    }
}
