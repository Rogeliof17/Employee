/**
 * Created by Genesis on 5/14/2016.
 */
public class InvalidShift extends Exception
{
    public InvalidShift()
    {
        super("ERROR: INVALID SHIFT NUMBER");
    }
}
