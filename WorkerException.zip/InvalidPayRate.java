/**
 * Created by Genesis on 5/14/2016.
 */
public class InvalidPayRate extends Exception
{
    public InvalidPayRate()
    {
        super("ERROR: NEGATIVE PAY RATE");
    }
}
